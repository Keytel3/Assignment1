document.getElementById("date").innerHTML = Date();
<input id="date" type="time" step="1"/>

function openNav() {
    document.getElementById("mysideNav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mysideNav").style.width = "0px";
}